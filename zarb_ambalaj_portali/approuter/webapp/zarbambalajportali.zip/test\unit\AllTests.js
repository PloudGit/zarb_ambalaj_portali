sap.ui.define(["comappabdiibrahim/zarb_ambalaj_portali/test/unit/controller/App.controller"],function(){"use strict"});
//# sourceMappingURL=AllTests.js.map