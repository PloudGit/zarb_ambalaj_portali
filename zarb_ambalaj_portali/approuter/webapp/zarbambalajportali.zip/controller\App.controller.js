sap.ui.define(["sap/ui/core/mvc/Controller"],r=>{"use strict";return r.extend("com.app.abdiibrahim.zarbambalajportali.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map