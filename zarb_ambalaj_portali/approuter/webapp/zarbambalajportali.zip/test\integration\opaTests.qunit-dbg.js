/* global QUnit */

sap.ui.require(["com/app/abdiibrahim/zarbambalajportali/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
