sap.ui.require(["com/app/abdiibrahim/zarbambalajportali/test/integration/AllJourneys"],function(){QUnit.config.autostart=false;QUnit.start()});
//# sourceMappingURL=opaTests.qunit.js.map