sap.ui.define(["sap/ui/base/ManagedObject"],function(a){"use strict";return a.extend("com.app.abdiibrahim.zarbambalajportali.utils.Mapping",{})});
//# sourceMappingURL=Mapping.js.map