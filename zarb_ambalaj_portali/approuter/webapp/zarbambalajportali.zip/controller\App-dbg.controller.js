sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("com.app.abdiibrahim.zarbambalajportali.controller.App", {
        onInit() {
        }
    });
});